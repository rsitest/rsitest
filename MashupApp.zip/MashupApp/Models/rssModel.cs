﻿namespace MashupApp.Models
{
    public class RssModel
    {
        public string Title { get; set; }
        public string Summary { get; set; }
    }
}